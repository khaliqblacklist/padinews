angular.module('WordApp.services', [])

/**
 * A simple example service that returns some data.
 */
.factory('DataLoader', function($http, $log) {

 return {
  get: function(url) {
   // Simple index lookup
   return $http.get(url);
  }
 }

})

.factory('Bookmark', function(CacheFactory) {

 if (!CacheFactory.get('bookmarkCache')) {
  CacheFactory.createCache('bookmarkCache');
 }

 var bookmarkCache = CacheFactory.get('bookmarkCache');

 return {
  set: function(id) {
   bookmarkCache.put(id, 'bookmarked');
   window.plugins.toast.showShortCenter(
    "Bookmarked",
    function(a) {},
    function(b) {}
   );
  },
  get: function(id) {
   bookmarkCache.get(id);
   console.log(id);
  },
  check: function(id) {
   var keys = bookmarkCache.keys();
   var index = keys.indexOf(id);
   if (index >= 0) {
    return true;
   } else {
    return false;
   }
  },
  remove: function(id) {
   bookmarkCache.remove(id);
   window.plugins.toast.showShortCenter(
    "Removed",
    function(a) {},
    function(b) {}
   );
  }

 }

})

.factory('$localstorage', ['$window', function($window) {
 return {
  set: function(key, value) {
   $window.localStorage[key] = value;
  },
  get: function(key, defaultValue) {
   return $window.localStorage[key] || defaultValue;
  },
  setObject: function(key, value) {
   $window.localStorage[key] = JSON.stringify(value);
  },
  getObject: function(key) {
   return JSON.parse($window.localStorage[key] || '{}');
  }
 }
}]);